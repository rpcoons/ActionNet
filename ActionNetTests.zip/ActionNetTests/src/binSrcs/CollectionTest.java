
import java.util.*;
import javafx.util.*;

public class CollectionTest {
    public static void main(String[] args) {
	Collection <Integer> c1,c2;

	// Part 1
	// Collection 1-10
	c1 = createRandCollect(1,10);
	// Collection 6-15
	c2 = createRandCollect(6,15);

	// Print both collections
	System.out.println("\nRandom Collections");
	System.out.println("Random Collection 1-10: "+c1.toString());
	System.out.println("Random Collection 6-15: "+c2.toString());

	// Print size of both collections
		System.out.println("\nRandom Collections Sizes");
	System.out.println("Random Collection 1-10 Size: "+c1.size());
	System.out.println("Random Collection 6-15 Size: "+c2.size());
	

	// Part 2
	// Create the Combined Collect according to test description
	System.out.println("\nCombined Collections Requested Results");
	Collection <Integer> c3 = createTestCombinedCollect(c1,c2);
	System.out.println("Sort Combined Collection Reverse Order : "+toStringReverseOrder(c3));
	System.out.println("Sort Combined Collection Size : "+c3.size());


	// Part 3
	/*
	  Using a HashMap yet technically not a Collection but is part of the JCF

	*/
	System.out.println("\nKey Value Example");
	// Create a map of key value objects.   Note the int will be converted to Integer
	Map <Integer, Pair<Integer,Integer>> map = new TreeMap<Integer, Pair<Integer,Integer>> ();
	for (int i=0; i<5; i++) {
	    Pair<Integer,Integer> kvpair = new Pair<Integer,Integer> (i,i+5);
	    map.put(kvpair.hashCode(),kvpair);
	}
	
	System.out.println("Initial key/value pairs: "+map.values().toString());

	System.out.println("Trying to Add some similar pairs: ");
	Pair<Integer,Integer> kvpair = new Pair<Integer,Integer> (1,6);
	if (map.get(kvpair.hashCode()) != null)
	    System.out.println("   kvpair<int,int> in hash map so will not add: "+kvpair.toString());
	else {
	    System.out.println("   kvpair<int,int> not in hash map so will add: "+kvpair.toString());
	    map.put(kvpair.hashCode(),kvpair);
	}

	kvpair = new Pair<Integer,Integer> (new Integer(1),6);
	if (map.get(kvpair.hashCode()) != null)
	    System.out.println("   kvpair<Integer,int> in hash map so will not add: "+kvpair.toString());
	else {
	    System.out.println("   kvpair<int,int> not in hash map so will add: "+kvpair.toString());
	    map.put(kvpair.hashCode(),kvpair);
	}

	System.out.println("After key/value pairs with types:\n"+
			   toStringKVPairCollection(map.values()));
	
	System.out.println("Final Map Size : "+map.size());	
	/*
	  The instructions said to create a collection of key/value pairs and not to let the same 
	  key/value pairs to be added.   This is best done with a hash key in a map.  The Pair class
	  is a key/value pair that creates a hash key based on value and type therefore I used this
	  to fulfill the requirements. Ideally one should never have arbitrary types in their pairs
	  yet I wanted to make the point.
	 */
    }


    // Create some sort of List
    public static Collection <Integer> createRandCollect(int start, int end) {
	Collection<Integer> list = new Vector<Integer> ();

	if (start > end) {int tmp=end; end=start; start=tmp;}
	for (int i=start; i<=end; i++) {
	    list.add(new Integer(i));
	}
	Collections.shuffle((List)list);
	return(list);
    }

    public static Collection <Integer> createTestCombinedCollect(Collection <Integer> c1, Collection <Integer> c2) {
	Collection<Integer> c3 = new TreeSet<Integer> (c1);
	c3.addAll(c2);

	int index = 0;
	int midindex = (c3.size()/2);
	for (Object o: c3) {
	    if (index == midindex) {
		c3.remove(o);
		break;
	    }
	    index++;
	}
	return(c3);	
    }
	
    public static String toStringReverseOrder(Collection<Integer> c) {
	String str = "";
	Iterator<Integer> it = c.iterator();
	while(it.hasNext()) {
	    Object o = it.next();
	    str = o.toString()+", "+str;
	}
	str = "["+str.substring(0,str.length()-2)+"]";
	return(str);
    }

    public static String toStringKVPairCollection(Collection<Pair<Integer,Integer>> c) {
	String str = "";
	Iterator <Pair<Integer,Integer>> it = c.iterator();
	while(it.hasNext()) {
	    Pair<Integer,Integer> p = it.next();
	    Object key = p.getKey();
	    Object val = p.getValue();
	    

	    str += "   <"+key.getClass().getName()+":"+key.toString()
		+"="+val.getClass().getName()+":"+val.toString()+">,\n";
	    
	}
	str = "  ["+str.substring(3,str.length()-2)+"]";

	return(str);
    }

    

	


    
}
