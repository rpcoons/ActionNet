import java.util.*;

public class ControlTest {

    public static void OneControl(int its) {
        for (int i = 1; i <= its; i++) {
            System.out.println
                (String.join("",Collections.nCopies(its-i,"."))+
                 String.join("",Collections.nCopies(i,Integer.toString(i))));
        }
    }
    
    public static void main(String[] args) {

        OneControl(5);
        OneControl(9);
    }


    
}
