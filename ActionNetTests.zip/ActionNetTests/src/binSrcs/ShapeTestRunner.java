import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class ShapeTestRunner {
    public static void main(String[] args) {
	Result result = JUnitCore.runClasses(TestCircle.class);
	for (Failure failure : result.getFailures()) {
	    System.out.println("Circle Test Failures: "+failure.toString());
	}
	System.out.println("Circle Test Sucess: "+result.wasSuccessful());

	result = JUnitCore.runClasses(TestSquare.class);
	for (Failure failure : result.getFailures()) {
	    System.out.println("Square Test Failures: "+failure.toString());
	}
	System.out.println("Square Test Sucess: "+result.wasSuccessful());

	result = JUnitCore.runClasses(TestRectangle.class);
	for (Failure failure : result.getFailures()) {
	    System.out.println("Rectangle Test Failures: "+failure.toString());
	}
	System.out.println("Rectangle Test Sucess: "+result.wasSuccessful());

	result = JUnitCore.runClasses(TestTriangle.class);
	for (Failure failure : result.getFailures()) {
	    System.out.println("Triangle Test Failures: "+failure.toString());
	}
	System.out.println("Triangle Test Sucess: "+result.wasSuccessful());

	result = JUnitCore.runClasses(TestQuadrilateral.class);
	for (Failure failure : result.getFailures()) {
	    System.out.println("Quadrilateral Test Failures: "+failure.toString());
	}
	System.out.println("Quadrilateral Test Sucess: "+result.wasSuccessful());
	
    }
}



