import org.junit.Test;
import static org.junit.Assert.*;
import Shapes.Point;
import Shapes.Quadrilateral;
import java.lang.Math;

public class TestQuadrilateral {
    protected Quadrilateral quad1;

    @Test
    public void setUp() {
	try {
	    quad1 = new Quadrilateral(new Point(0,0),new Point(10,0),new Point(0,10),new Point(10,10));
	}
	catch (Exception e) {
	    System.out.println(e.toString());
	}
    }
    
    public void testAdd() {
	assertTrue(quad1.getArea() == 50);
	assertTrue(quad1.getPerimeter() == 40);
    } 
}
