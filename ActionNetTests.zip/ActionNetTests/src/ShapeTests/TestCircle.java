import org.junit.Test;
import static org.junit.Assert.*;
import Shapes.Circle;
import java.lang.Math;

public class TestCircle {
    protected Circle circle;

    @Test
    public void setUp() {
        circle = new Circle(10/Math.PI);
    }
    
    public void testAdd() {
        assertTrue(circle.getArea() == 100);
        assertTrue(circle.getPerimeter() == 20);
    } 
}
