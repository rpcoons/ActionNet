import java.text.*;
import Shapes.*;


public class TestShapes {

    public static void main(String[] args) {
	try {
	    DecimalFormat df = new DecimalFormat("#.00");

	    Triangle tri = new Triangle(10,5);
	    System.out.println("Triangle Area: "+df.format(tri.getArea())+
			       " Triangle Perimeter: "+df.format(tri.getPerimeter())); 

	    

	    Square sqr = new Square(10);
	    System.out.println("Square Area: "+df.format(sqr.getArea())+
				       " Square Perimeter: "+df.format(sqr.getPerimeter())); 

	    sqr = new Square(new Point(0,0),new Point(10,0),new Point(10,10),new Point(0,10));
	    System.out.println("Square Area: "+df.format(sqr.getArea())+
			       " Square Perimeter: "+df.format(sqr.getPerimeter())); 

	    Quadrilateral quad = new Quadrilateral(new Point(0,0),new Point(10,0),new Point(0,10),new Point(10,10));
	    System.out.println("Quad Area: "+df.format(quad.getArea())+
			       " Quad Perimeter: "+df.format(quad.getPerimeter())); 
	    
	    
	    Rectangle rect = new Rectangle(10,20);
	    System.out.println("Rectangle Area: "+df.format(rect.getArea())+
			       " Rectangle Perimeter: "+df.format(rect.getPerimeter())); 

	    Circle circle = new Circle(5);
	    System.out.println("Circle Area: "+ df.format(circle.getArea())+
			       " Circle Perimeter: "+ df.format(circle.getPerimeter()));
	}
	catch (Exception e) {
	    System.out.println(e.toString());
	}
    }
}


