import org.junit.Test;
import static org.junit.Assert.*;
import Shapes.Point;
import Shapes.Square;
import java.lang.Math;

public class TestSquare {
    protected Square sqr1;
    protected Square sqr2;

    @Test
    public void setUp() {
        try {
            sqr1 = new Square(10);
            sqr2 = new Square(new Point(0,0),new Point(10,0),new Point(10,10),new Point(0,10));
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    
    public void testAdd() {
        assertTrue(sqr1.getArea() == 100);
        assertTrue(sqr1.getPerimeter() == 40);
        assertTrue(sqr2.getArea() == 100);
        assertTrue(sqr2.getPerimeter() == 40);
    } 
}
