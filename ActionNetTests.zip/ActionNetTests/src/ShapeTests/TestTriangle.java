import org.junit.Test;
import static org.junit.Assert.*;
import Shapes.Point;
import Shapes.Triangle;
import java.lang.Math;

public class TestTriangle {
    protected Triangle tri1;
    protected Triangle tri2;

    @Test
    public void setUp() {
	try {
	    tri1 = new Triangle(10,5);
	    tri2 = new Triangle(new Point(0,0),new Point(10,0),new Point(5,5));
	}
	catch (Exception e) {
	    System.out.println(e.toString());
	}
    }
    
    public void testAdd() {
	assertTrue(tri1.getArea() == 25);
	assertTrue(tri1.getPerimeter() == 24.14);
	assertTrue(tri2.getArea() == 24);
	assertTrue(tri2.getPerimeter() == 24.14);
    } 
}
