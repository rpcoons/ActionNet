import org.junit.Test;
import static org.junit.Assert.*;
import Shapes.Point;
import Shapes.Rectangle;
import java.lang.Math;

public class TestRectangle {
    protected Rectangle rect1;
    protected Rectangle rect2;

    @Test
    public void setUp() {
        try {
            rect1 = new Shapes.Rectangle(10,20);
            rect2 = new Shapes.Rectangle(new Point(0,0),
                                         new Point(20,0),
                                         new Point(20,10),
                                         new Point(0,10));
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    
    public void testAdd() {
        assertTrue(rect1.getArea() == 200);
        assertTrue(rect1.getPerimeter() == 60);
        assertTrue(rect2.getArea() == 200);
        assertTrue(rect2.getPerimeter() == 60);
    } 
}
