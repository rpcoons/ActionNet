package Shapes;

import java.text.*;

public class LineSegment {
    private Point pt1,pt2;
    private double M;
    private double B;

    public LineSegment(Point pt1, Point pt2) {
        this.pt1 = new Point(pt1);
        this.pt2 = new Point(pt2);

        M = (pt1.getY() - pt2.getY())/(pt1.getX() - pt2.getX());
        B = pt1.getY() - M*pt1.getX();
    }

    public Point intersectPoint(LineSegment lseg) {
        double x = (lseg.getB()-B)/(M-lseg.getM());
        if (Double.isInfinite(x)) return(null);
        if (Double.isNaN(x)) return(null);
        
        double y = M*x+B;
        Point pt = new Point(x,y);
        if (!isPointInBounds(pt)) return(null);
        if (!lseg.isPointInBounds(pt)) return(null);
        return(pt);
    }

    public boolean isPointInBounds(Point pt) {
        double x = pt.getX();
        double y = pt.getY();

        if ((x < pt1.getX()) && (x < pt2.getX())) return (false);
        if ((x > pt1.getX()) && (x > pt2.getX())) return (false);
        if ((y < pt1.getY()) && (y < pt2.getY())) return (false);
        if ((y > pt1.getY()) && (y > pt2.getY())) return (false);
        return(true);

    }
    
    public double getM() {return(M);}
    public double getB() {return(B);}

    public String toString() {
        DecimalFormat df = new DecimalFormat("#.00");
        return("Line Segment: from "+pt1.toString()+" to "+pt2.toString()+
               " has M="+df.format(M)+", B="+df.format(B));
    }
}
