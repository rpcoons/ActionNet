package Shapes;

import java.util.*;

public class Triangle extends ConvexPolygon implements Shape {
    public Triangle(double base, double height) throws Exception {
	super(new ArrayList<Point>
	      (Arrays.asList
	       (new Point(-0.5*base,0),
		new Point(0.5*base,0),
		new Point(0,height))),
	      3);
    }
    public Triangle(Point pt0, Point pt1, Point pt2)  throws Exception {
	super(new ArrayList<Point>(Arrays.asList(pt0,pt1,pt2)),3);
    }	
    public Triangle(ArrayList<Point> pts) throws Exception {
	super(pts,3);
    }
}
