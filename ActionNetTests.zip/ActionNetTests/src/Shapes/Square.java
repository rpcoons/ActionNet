package Shapes;
    
import java.lang.Exception;

public class Square extends Rectangle implements Shape {

    public Square(double length) throws Exception  {
	super(length,length);
    }
    public Square (Point pt0, Point pt1, Point pt2, Point pt3) throws Exception {
	super(pt0,pt1,pt2,pt3);
	double len1 = pt0.lengthTo(pt1);
	double len2 = pt0.lengthTo(pt3);
	if (len1 != len2) throw new Exception("Not a square");
    }
}
