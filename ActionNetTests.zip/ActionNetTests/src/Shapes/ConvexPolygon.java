package Shapes;

import java.util.*;
import java.lang.Exception;
import java.text.*;

public class ConvexPolygon implements Shape {
    private ArrayList <Point>points = null;
    private double area = 0;
    private double perimeter = 0;

    public ConvexPolygon(ArrayList<Point> points) throws Exception {
        this(points,0);
    }
    
    public ConvexPolygon(ArrayList<Point> points, int reqNPts) throws Exception {
        this.points = new ArrayList <Point> ();
        Iterator<Point> it = points.iterator();
        // Remove adjact duplicates

        if (it.hasNext()) {
            Point firstPt = it.next();
            this.points.add(new Point(firstPt));
            Point lastPt = firstPt;
            while(it.hasNext()) {
                Point p = it.next();
                if (p.isEqual(lastPt)) {continue;}
                this.points.add(new Point(p));
                lastPt = p;
            }
            if (!firstPt.isEqual(lastPt)) {this.points.remove(lastPt);}
        }
        if (this.points.size() < 2) throw new Exception("Polygons need at least 3 points");
        if ((reqNPts > 0) && (this.points.size() != reqNPts)) {
            throw new Exception("Polygon does not fit the needed requirement of "+reqNPts+" points");
        }

        perimeter = calcPerimeter();
        area = calcArea();
    }

    private double calcPerimeter() {
        double p = 0;
        Iterator<Point> it = points.iterator();
        Point firstPt = it.next();
        Point lastPt = firstPt;
        while(it.hasNext()) {
            Point pt = it.next();
            p += pt.lengthTo(lastPt);
            lastPt = pt;
        }
        p += lastPt.lengthTo(firstPt);
        return(p);
    }

    private double calcArea() {
        double area = 0;
        Iterator<Point> it = points.iterator();
        Point firstPt = it.next();
        Point lastPt = firstPt;
        while(it.hasNext()) {
            Point pt = it.next();
            area += (lastPt.getX()*pt.getY() -
                     lastPt.getY()*pt.getX());
            lastPt = pt;
        }
        area += (lastPt.getX()*firstPt.getY() -
                 lastPt.getY()*firstPt.getX());
        area /= 2;
        if (area < 0) area *= -1;
        return(area);
    }
    public Point getPointAt(int index) {
        return(new Point(points.get(index)));
    }
        
    public double getArea() {return(area);}
    public double getPerimeter() {return(perimeter);}

    public String toString() {
        DecimalFormat df = new DecimalFormat("#.00");
        String str = "";
        str += "ConvexPoly with Pts: "+points.toString()+"\n"+
            "has Area="+df.format(area)+"\n"+
            "and Perimeter="+df.format(perimeter)+"\n";
        return(str);
    }
    
}
