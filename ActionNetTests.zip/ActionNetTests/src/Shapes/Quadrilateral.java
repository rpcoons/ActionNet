package Shapes;

import java.lang.Exception;
import java.util.*;

public class Quadrilateral implements Shape {
    ConvexPolygon cps[];
    double area = 0;
    double perimeter = 0;
    
    public Quadrilateral(double length, double width) throws Exception {
        cps = new ConvexPolygon[1];
        try {
            cps[0] = new ConvexPolygon
                (new ArrayList<Point>
                 (Arrays.asList
                  (new Point(-0.5*length,-0.5*width),
                   new Point(0.5*length,-0.5*width),
                   new Point(0.5*length,0.5*width),
                   new Point(-0.5*length,0.5*width))),
                 4);
        }
        catch (Exception e) {throw new Exception("Not a quadrilateral");}
        area = cps[0].getArea();
        perimeter = cps[0].getPerimeter();
    }
    
    public Quadrilateral(Point pt0, Point pt1, Point pt2, Point pt3) throws Exception {
        this(new ArrayList<Point>(Arrays.asList(pt0,pt1,pt2,pt3)));
    }

    public Quadrilateral(ArrayList<Point> pts) throws Exception {
        ConvexPolygon cp;
        try {cp = new ConvexPolygon(pts,4);}
        catch (Exception e) {throw new Exception("Not a quadrilateral");}
        try {
            Point a = cp.getPointAt(0);
            Point b = cp.getPointAt(1);
            Point c = cp.getPointAt(2);
            Point d = cp.getPointAt(3);

            cps = new ConvexPolygon[1];

            cps[0] = new ConvexPolygon(pts);

            LineSegment ab = new LineSegment(a,b);
            LineSegment cd = new LineSegment(c,d);
            Point pt = ab.intersectPoint(cd);
            if (pt != null) {
                cps = new ConvexPolygon[2];
                cps[0] = new Triangle(pt,a,d);
                cps[1] = new Triangle(pt,b,c);
            }
            else {
                LineSegment ad = new LineSegment(a,d);
                LineSegment bc = new LineSegment(b,c);
                pt = ad.intersectPoint(bc);
                if (pt != null) {
                    cps = new ConvexPolygon[2];
                    cps[0] = new Triangle(pt,a,b);
                    cps[1] = new Triangle(pt,c,d);
                }
            }
            area = 0; perimeter=0;
            for (int i=0; i<cps.length; i++) {
                area += cps[i].getArea();
                perimeter += cps[i].getPerimeter();
            }
        }
        catch (Exception e) {e.printStackTrace();}
    }
    
    public double getArea() {return(area);}
    public double getPerimeter() {return(perimeter);}
}
