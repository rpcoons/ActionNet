package Shapes;

import java.lang.Math;
import javafx.util.*;
import java.text.*;

public class Point {
    Pair <Double,Double> xy;

    public Point(double x, double y) {
	xy = new Pair <Double,Double> (x,y);
    }    
    public Point(Point p) {
	xy = new Pair <Double,Double> (p.getX(),p.getY());	
    }    

    public double getX() {return((double)xy.getKey());}
    public double getY() {return((double)xy.getValue());}
    
    public double lengthTo(Point pt) {
	double alen = (pt.getX() - getX());
	double blen = (pt.getY() - getY());
	return(Math.sqrt(alen*alen + blen*blen));
    }

    public boolean isEqual(Point pt) {
	return((xy.hashCode() == pt.hashCode())); 
    }
    public String toString() {
	DecimalFormat df = new DecimalFormat("#.00");
	return("("+df.format(xy.getKey())+","+df.format(xy.getValue())+")");
    }
    
}
