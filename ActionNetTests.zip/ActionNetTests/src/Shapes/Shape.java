package Shapes;

public interface Shape {
    public double getArea();
    public double getPerimeter();
}






