package Shapes;

import java.lang.Exception;

public class Rectangle extends Quadrilateral implements Shape {
    public Rectangle(double length, double width) throws Exception {
        super(length,width);
    }
    public Rectangle(Point pt0, Point pt1, Point pt2, Point pt3) throws Exception {
        super(pt0,pt1,pt2,pt3);
        double len1 = pt0.lengthTo(pt2);
        double len2 = pt1.lengthTo(pt3);
        if (len1 != len2) throw new Exception("Not a rectangle");
    }
}
